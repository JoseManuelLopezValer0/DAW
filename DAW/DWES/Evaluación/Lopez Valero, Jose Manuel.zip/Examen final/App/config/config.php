<?php
define("DIRBASEURL", "public\index.php ");
define("DIRPUBLIC", "public");

define("DBHOST", "localhost");
define("DBNAME", "ex_gestion_multas_2223");
define("DBUSER", "root");
define("DBPASS", "");
